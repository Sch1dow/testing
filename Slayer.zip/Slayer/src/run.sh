#!/bin/bash

test_dir=$1

$(dirname "$0")/run_slayer.sh $test_dir

